import React, { useEffect } from "react";

const PayChecks = () => {
  useEffect(() => {}, []);
  return <div></div>;
};

export default PayChecks;
